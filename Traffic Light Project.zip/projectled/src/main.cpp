#include <Arduino.h> 

int red = 19;
int yellow = 5;
int green = 16;

void setup() {
 pinMode(red, OUTPUT);
 pinMode(yellow, OUTPUT);
 pinMode(green, OUTPUT);
}

void loop() {
 digitalWrite(green, HIGH);
 delay(30000);
 digitalWrite(green, LOW);

 digitalWrite(yellow, HIGH);
 delay(5000);
 digitalWrite(yellow, LOW);

 digitalWrite(red, HIGH);
 delay(20000);
 digitalWrite(red, LOW);
}
